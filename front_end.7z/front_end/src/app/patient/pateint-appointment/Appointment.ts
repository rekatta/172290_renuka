export class Appointment{
    patientEmail:string;
	problem:string;
	location:string;
	doctorName:string;
	doctorEmail:string;
	date:Date;
	patientName:string;
    
}



