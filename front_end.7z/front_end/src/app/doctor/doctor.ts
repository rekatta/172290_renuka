export class Doctor{
    emailId:string;
    name:string;
    qualification:string;
    location:string;
    experience:string;
    specilization:string;
    phoneNumber:string;
   
    password:string;
    age:number;
  username: any;
}